// (c) Copyright 1995-2026 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:pc_unit:1.0
// IP Revision: 1

`timescale 1ns/1ps

(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module RISCV_COCOTB_pc_unit_0_0 (
  rst,
  clk,
  pc_en,
  priv_redirect_valid,
  priv_redirect_target,
  pc_redirect_valid,
  pc_redirect_target,
  pc_predict_valid,
  pc_predict_next,
  pc,
  pc_plus4,
  pc_debug_last_priv_redirect,
  pc_debug_priv_redirect_pulse,
  pc_debug_last_redirect,
  pc_debug_redirect_pulse,
  pc_debug_last_predict,
  pc_debug_predict_pulse
);

(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst RST" *)
input wire rst;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 190474289, FREQ_TOLERANCE_HZ 0, PHASE 0.000, CLK_DOMAIN BASIC_zynq_ultra_ps_e_0_0_pl_clk0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *)
input wire clk;
input wire pc_en;
input wire priv_redirect_valid;
input wire [31 : 0] priv_redirect_target;
input wire pc_redirect_valid;
input wire [31 : 0] pc_redirect_target;
input wire pc_predict_valid;
input wire [31 : 0] pc_predict_next;
output wire [31 : 0] pc;
output wire [31 : 0] pc_plus4;
output wire [31 : 0] pc_debug_last_priv_redirect;
output wire pc_debug_priv_redirect_pulse;
output wire [31 : 0] pc_debug_last_redirect;
output wire pc_debug_redirect_pulse;
output wire [31 : 0] pc_debug_last_predict;
output wire pc_debug_predict_pulse;

  pc_unit #(
    .RESET_PC(32'H00000000)
  ) inst (
    .rst(rst),
    .clk(clk),
    .pc_en(pc_en),
    .priv_redirect_valid(priv_redirect_valid),
    .priv_redirect_target(priv_redirect_target),
    .pc_redirect_valid(pc_redirect_valid),
    .pc_redirect_target(pc_redirect_target),
    .pc_predict_valid(pc_predict_valid),
    .pc_predict_next(pc_predict_next),
    .pc(pc),
    .pc_plus4(pc_plus4),
    .pc_debug_last_priv_redirect(pc_debug_last_priv_redirect),
    .pc_debug_priv_redirect_pulse(pc_debug_priv_redirect_pulse),
    .pc_debug_last_redirect(pc_debug_last_redirect),
    .pc_debug_redirect_pulse(pc_debug_redirect_pulse),
    .pc_debug_last_predict(pc_debug_last_predict),
    .pc_debug_predict_pulse(pc_debug_predict_pulse)
  );
endmodule
